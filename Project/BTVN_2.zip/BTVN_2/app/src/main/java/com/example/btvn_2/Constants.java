package com.example.btvn_2;

public class Constants {
    public static final int RESULT_CODE_OK = 38;
}
